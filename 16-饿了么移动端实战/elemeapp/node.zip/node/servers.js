
const Koa=require("koa");//运行环境
//处理路由
const Router = require('koa-router')
const cors=require("kcors")//解决跨域


const app=new Koa();

const router = new Router()
//需要传回的数据
const homeData=require("./homemsg/category")
console.log(homeData)

//开放的接口
app.use(cors())
//开放静态资源
app.use(require("koa-static")(__dirname+"/static/images"))
    //对不同路由返回的不同数据

router.get('/api/shop',function (ctx) {
    ctx.body = homeData;
    console.log(homeData)
})




app.use(router.routes()).use(router.allowedMethods())

//监听的端口
app.listen(6666,function () {
    console.log("启动成功")
})