const data = [
    {
        img: 'http://47.105.76.238:6666/category/1.png',
        title: '美食'
    },
    {
        img: 'http://47.105.76.238:6666/category/2.png',
        title: '甜品饮品'
    }
]

module.exports = data